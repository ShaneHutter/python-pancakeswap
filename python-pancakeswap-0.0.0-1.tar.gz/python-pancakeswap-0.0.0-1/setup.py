#!/usr/bin/env python3
"""setup.py

Description:
    Tool for packaging
"""

from pancakeswap    import PKG_INFO
from distutils.core import setup

setup( **PKG_INFO )
